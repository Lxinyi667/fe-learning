<script setup lang="ts">
import Concat from '../components/Concat.vue';
</script>

<template>
  <Concat></Concat>
</template>


