<template>
  <div class="w-full flex px-6">
    <Card></Card>
    <Card></Card>
    <Card></Card>
  </div>
</template>

<script setup>
import Card from '../components/Card.vue';
</script>
