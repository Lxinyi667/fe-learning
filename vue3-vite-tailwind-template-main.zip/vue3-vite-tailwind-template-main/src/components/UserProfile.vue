<template>
  <div class='flex items-center justify-center h-screen from-indigo-100 via-blue-200 to-indigo-400 bg-gradient-to-br'>
    <Concat></Concat>
  </div>
</template>

<script setup>
import Concat from './Concat.vue';
</script>

