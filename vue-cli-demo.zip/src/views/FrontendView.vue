<template>
    <div>
        <div  class="itemlist-box">
            <!----> 
            <div  class="content">
                <a  target="_blank" class="title">
                    Android 架构之 MVI 完全体 | 重新审视 MVVM 之殇，PartialChange &amp; Reducer 来拯救</a>
                <div  class="abstract">
                    这是 MVI 架构的第三篇，系列文章目录如下： Android 架构之 MVI 雏形 | 响应式编程 + 单向数据流 + 唯一可信数据源[https://juejin.cn/post/7087717...
                </div> 
                <img  referrerpolicy="no-referrer" src="../assets/images/love2.png" alt="">
            </div>
            <div  class="content">
                <a  target="_blank" class="title">
                    前端VUE3,JQ,uniapp,综合(Ctrl+F搜索)
                </a> 
                <div  class="abstract">
                    对象解构赋值 直接要哪个解构哪个 uniapp模板中调用import的方法 引入方法后 ,js代码中可以正常调用 ,想在模板中直接调用引入的方法需要在methods区域声明,才能直接在模板中调用 J...</div> 
                <img  referrerpolicy="no-referrer" src="../assets/images/love3.png" alt="">
            </div>
        </div>
    </div>
</template>

<script setup>

</script>

<style  scoped>
*{
    margin:0;
    padding:0;
    list-style: none;
    text-decoration: none;
    color: black;
}
.itemlist-box {
    position: relative;
    margin: 0 0 15px;
    padding: 30px 15px 20px 15px;
}
.title{
    font-weight: 1000;                                                                          
    font-size: 20px;
    
}
.abstract{
    margin-top: 10px;
    color: gray;
    font-size: 14px;
}
img{
  height: 30px;
}
</style>