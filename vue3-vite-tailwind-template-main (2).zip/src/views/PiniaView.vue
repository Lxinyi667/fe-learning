<script setup>
import TodoApp from '../components/TodoApp.vue';
</script>

<template>
    <div class="px-2 py-10 m-10 w-100 h-80 bg-slate-200 text-center">
        <TodoApp></TodoApp>
    </div>
</template>

<style scoped>

</style>