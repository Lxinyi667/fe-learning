<script setup>

</script>

<template>
    <div>
        <button type="sumbit" class="px-12 py-2 bg-cyan-600 text-white rounded-3xl my-2">
        Submit
      </button>
    </div>
</template>

<style scoped>

</style>