<template>
	<view>
		发现
	</view>
</template>

<script setup>
	
</script>

<style>

</style>
