<template>
	<view class="mt-2 flex justify-between px-2">
		<view class="flex-1 pr-2">
			<input type="text" class="bg-cyan-100/30 rounded pl-3 py-3 border focus:outline-none focus:border-cyan-500"
				value="Search">
		</view>
		<view>
			<button class="btn bg-cyan-500 text-white px-4 font-medium rounded">调序</button>
		</view>
	</view>
</template>
