<script setup></script>

<template></template>

<style>
	@import 'tailwindcss/base';
	@import 'tailwindcss/utilities';
	@import 'tailwindcss/components';
	@import 'common/iconfont.css';

	body {
		background-color: #f8f8f8;
	}
</style>